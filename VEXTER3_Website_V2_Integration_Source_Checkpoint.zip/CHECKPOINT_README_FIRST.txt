VEXTER3 WEBSITE V2 — SOURCE CHECKPOINT ONLY
This archive contains the integration HTML/CSS/JS and notes, but EXCLUDES image assets to keep it small for GitHub/mobile upload. It is NOT a standalone visual backup or deployable complete website. Approved Hero Library V2 assets/profiles are saved separately in the GitHub development branch. Approved Events Library backup ZIP and Rate My Squad HTML are also saved separately in the same branch.
DO NOT DEPLOY OR MERGE TO MAIN WITHOUT USER APPROVAL.
