VEXTER3 1.0 multipage site

Upload ALL files and the assets folder to the root of your GitHub Pages repository. Keep the folder structure intact. GitHub Pages opens index.html automatically.

The homepage is index.html. Each guide section has its own HTML page. English/French switch is remembered in the browser. Images are in assets/. Search works across the guide sections.

INTEGRATION: Hero Library is at hero-library/index.html and linked from the shared navigation and Heroes & Squads page. Both sections use the vxtr-language setting. Deploy entire folder to static hosting; the library fetches heroes.json and may not run directly via file://. Content remains subject to screenshot verification.
